package sv.edu.udb.spring_api_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCienciasdelacomputacionJj646ApplicationTests {

	@Test
	void contextLoads() {
	}

}
