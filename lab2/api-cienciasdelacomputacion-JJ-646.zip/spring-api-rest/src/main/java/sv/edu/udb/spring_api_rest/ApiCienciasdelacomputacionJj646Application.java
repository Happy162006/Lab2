package sv.edu.udb.spring_api_rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCienciasdelacomputacionJj646Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiCienciasdelacomputacionJj646Application.class, args);
	}

}
